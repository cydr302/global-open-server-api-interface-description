## Request parameters:

|Parameter name|Type|Illustration|
|:----    |:----- |-----   |
|callTime   |long |The time stamp for sending the callback.   |
|callbackType   |String |Callback type   |
|iotId |long|Machine ID   |
|orderId|String |Order ID  |
|volume|int|Surplus water(ml),the following is the scheme of 2000ml, the actual water output is 1500ml, and 500 is returned here.|