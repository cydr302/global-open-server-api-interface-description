#### Equipment Description:
- The rollover car washing machine needs to issue a car washing plan first, and then wait for the vehicle to stop before starting the vehicle.
- If your device is equipped with a parking gate, the parking gate will be lifted when the lock is successful.
- The locked device can no longer accept the new lock request, and the lock is occupied.
- It is recommended to check the status of the equipment before each operation.