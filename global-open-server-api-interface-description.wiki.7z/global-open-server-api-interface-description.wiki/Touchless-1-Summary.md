#### Equipment Description:
- The touchless car washing machine needs to issue a car washing plan first, and then wait for the vehicle to stop before starting the vehicle.
- The locked device can no longer accept the new lock request, and the lock is occupied.
- It is recommended to check the status of the equipment before each operation.