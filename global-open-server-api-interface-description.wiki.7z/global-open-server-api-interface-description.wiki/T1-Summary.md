 **Equipment Description:** 
- The car washing plan was issued and the car washing started when it was successful.
- The car washing process can be suspended, continued and reset.
- It is recommended to check the status of the equipment before each operation.