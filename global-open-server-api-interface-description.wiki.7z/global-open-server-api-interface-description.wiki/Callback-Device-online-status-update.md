## Request parameters:

|Parameter name|Type|Illustration|
|:----    |:----- |-----   |
|callTime   |long |The time stamp for sending the callback.   |
|callbackType   |String |Callback type   |
|iotIdList   |Array |Changed Machine ID   |
|status   |int|Online status, 1 for online, 0 for offline.  |