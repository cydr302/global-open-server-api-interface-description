# API document of the open platform (International Edition) for Car Friend

The the open platform (International Edition) for Car Friend is committed to providing the merchant with complete online operation solutions for the equipment and providing the function of online joint debugging.

#### Server address:

|Development environment|API access address|The login address of management system|
|:----    |:---|:----- |
|**production environment** |   |  |
|**development environment** |   |  |

#### About the development environment
- The data of production environment and development environment are completely separated and independent, and there is no intersection.
- All the devices in the development environment are virtual devices, and there are no real devices.
- The car washer machine and other equipment you buy in our company will appear in the production environment for your use.
- If you need to perform a real machine test, use the production environment.
- Data in the development environment is not guaranteed to be completely reliable, and unplanned data adjustments may occur due to business adjustments,Please refer to the real-time data of the interface.