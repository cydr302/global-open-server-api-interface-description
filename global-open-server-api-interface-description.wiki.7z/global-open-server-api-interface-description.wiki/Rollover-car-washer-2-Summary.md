#### Equipment Description:
- Rollover car washer 2 needs to check the parking state first.
- After the vehicle is parked, the car washing operation can be started.
- The car washing process can be suspended, continued, and emergency stopped.
- The device type is NFULL_AUTO_2.
- If the pause time is too long, the device will reset automatically and end the car washing.